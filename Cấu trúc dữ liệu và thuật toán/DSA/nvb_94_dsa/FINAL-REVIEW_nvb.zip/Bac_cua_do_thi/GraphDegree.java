
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
@SuppressWarnings({"unchecked", "deprecation"})
public class GraphDegree {
	
	private int[][] matrix;// ma trận kề
	private String[] v;// danh sách các đỉnh
	private int n;// số đỉnh
	
	public void loadGraphFromFile(String fileName)
	{
		try {
			File file = new File(fileName);
			Scanner getData = new Scanner(file);
			n = Integer.parseInt(getData.nextLine());
			v = new String[n];
			matrix = new int[n][n];

			for (int i = 0; i < n; i++) {
				v[i] = getData.nextLine().trim();
			}
			for (int i = 0; i < n; i++) {
				String data = getData.nextLine().trim();
				matrix[i] = parseDataToArray(data);
			}

			getData.close();
		} catch (FileNotFoundException e) {
			System.out.println("File " + fileName + " not found!");
			e.printStackTrace();
		}
	}

	private int[] parseDataToArray(String data) {
		String[] tokens = data.split(" ");
		int[] arr = new int[tokens.length];
		for (int i = 0; i < tokens.length; i++) {
			arr[i] = Integer.parseInt(tokens[i]);
		}
		return arr;
	}

	
	public int[] getDegree()
	{
		int[] degree = new int[n];
		Arrays.fill(degree, 0);
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (matrix[i][j] == 1) {
					degree[i]++;
				}
			}
		}
		return degree;
	}

}
