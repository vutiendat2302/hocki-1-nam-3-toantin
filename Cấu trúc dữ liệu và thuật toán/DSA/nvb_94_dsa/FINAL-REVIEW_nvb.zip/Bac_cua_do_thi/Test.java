public class Test {
    private static GraphDegree graphDegree;
    public static void main(String[] args) {
        graphDegree = new GraphDegree();
        graphDegree.loadGraphFromFile("nearList.txt");

        int[] degree = graphDegree.getDegree();
        for (int deg : degree) {
            System.out.println(deg + " ");
        }
    }
}
