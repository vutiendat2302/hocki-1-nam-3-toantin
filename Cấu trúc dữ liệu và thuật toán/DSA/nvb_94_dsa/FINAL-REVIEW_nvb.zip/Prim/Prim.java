import java.util.*;

public class Prim {
    private int numVertices;
    private int[][] graph;

    /**
     * Khởi tạo đối tượng với ma trận kề của đồ thị.
     *
     * @param graph Ma trận kề thể hiện trọng số các cạnh. 9999 biểu thị không có cạnh.
     */
    public Prim(int[][] graph) {
        this.numVertices = graph.length;
        this.graph = graph;
    }

    /**
     * Thực hiện thuật toán Prim2 để tìm MST.
     *
     * @return mảng parent, trong đó parent[i] là đỉnh cha của đỉnh i trong MST.
     */
    public int[] primMST() {
        int[] keys = new int[numVertices];
        boolean[] visited = new boolean[numVertices];
        int[] parents = new int[numVertices];
        Arrays.fill(keys, Integer.MAX_VALUE);
        Arrays.fill(visited, false);

        int startIndex = 0;

        keys[startIndex] = 0;
        parents[startIndex] = -1;

        for (int i = 0; i < numVertices - 1; i++) {
            int u = minKeyIndex(keys, visited);

            if (u == -1 || keys[u] == Integer.MAX_VALUE) {
                System.out.println("Khong lien thong!");
                throw new IllegalStateException("Khong lien thong!");
            }

            visited[u] = true;

            for (int v = 0; v < graph.length; v++) {
                if (!visited[v]
                && graph[u][v] != 9999
                && graph[u][v] < keys[v]) {
                    keys[v] = graph[u][v];
                    parents[v] = u;
                }
            }
        }
        return parents;
    }

    private int minKeyIndex(int[] keys, boolean[] visited) {
        int min = Integer.MAX_VALUE;
        int minIndex = -1;

        for (int i = 0; i < keys.length; i++) {
            if (!visited[i] && keys[i] <= min) {
                min = keys[i];
                minIndex = i;
            }
        }
        return minIndex;
    }


    /**
     * In kết quả MST.
     */
    public void printMST(int[] parent) {
        System.out.println("Cạnh \tTrọng số");
        int totalWeight = 0;

        for (int i = 1; i < graph.length; i++) {
            if (parent[i] != -1) {
                System.out.println(parent[i] + " - " + i + "\t" + graph[i][parent[i]]);
                totalWeight += graph[i][parent[i]];
            }
        }

        System.out.println("Tổng trọng số MST: " + totalWeight);
    }
}
