public class PrimTest {
    public static void main(String[] args) {
        System.out.println("=== KIỂM TRA THUẬT TOÁN PRIM MST ===\n");

        // Test case 1: Đồ thị liên thông
        testCase1();

        // Test case 2: Đồ thị không liên thông
        testCase2();
    }

    public static void testCase1() {
        System.out.println("--- TEST CASE 1: Đồ thị liên thông ---");

        int[][] graph = {
                {0,    2,    9999, 6,    9999},
                {2,    0,    3,    8,    5},
                {9999, 3,    0,    9999, 7},
                {6,    8,    9999, 0,    9},
                {9999, 5,    7,    9,    0}
        };

        Prim prim = new Prim(graph);
        int[] parent = prim.primMST();
        prim.printMST(parent);
        System.out.println();
    }

    public static void testCase2() {
        System.out.println("--- TEST CASE 2: Đồ thị không liên thông ---");

        int[][] graph = {
                {0,    1,    9999, 9999},
                {1,    0,    9999, 9999},
                {9999, 9999, 0,    2},
                {9999, 9999, 2,    0}
        };

        Prim prim = new Prim(graph);
        int[] parent = prim.primMST();
        prim.printMST(parent);
        System.out.println();
    }
}
