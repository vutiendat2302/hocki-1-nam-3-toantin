package key;

import java.util.Arrays;

public class Prim2 {
    private int numVertices;
    private int[][] graph;

    /**
     * Khởi tạo đối tượng với ma trận kề của đồ thị.
     *
     * @param graph Ma trận kề thể hiện trọng số các cạnh. 9999 biểu thị không có cạnh.
     */
    public Prim2(int[][] graph) {
        this.numVertices = graph.length;
        this.graph = graph;
    }

    /**
     * Thực hiện thuật toán Prim2 để tìm MST.
     *
     * @return mảng parent, trong đó parent[i] là đỉnh cha của đỉnh i trong MST.
     */
    public int[] primMST() {
        int[] key = new int[numVertices];
        boolean[] visited = new boolean[numVertices];
        int[] parent = new int[numVertices];

        Arrays.fill(key, Integer.MAX_VALUE);
        Arrays.fill(visited, false);

        int startIndex = 0;
        key[startIndex] = 0;
        parent[startIndex] = -1;

        for (int i = 0; i < numVertices - 1; i++) {
            int u = minKeyIndex(key, visited);

            if (u == -1) {
                throw new IllegalStateException("Khong phai do thi lien thong!");
            }

            visited[u] = true;

            for (int v = 0; v < numVertices; v++) {
                if (!visited[v]
                && graph[u][v] != 9999
                && graph[u][v] < key[v]) {
                    key[v] = graph[u][v];
                    parent[v] = u;
                }
            }
        }
        return parent;
    }
    
    private int minKeyIndex(int[] key, boolean[] visited) {
        int min  =Integer.MAX_VALUE;
        int minIndex = -1;
        for (int i = 0; i < numVertices; i++) {
            if (!visited[i] && key[i] <= min) {
                min = key[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    public void printMST(int[] parent) {
        System.out.println("Cạnh \tTrọng số");
        int totalWeight = 0;

        for (int i = 1; i < graph.length; i++) {
            if (parent[i] != -1) {
                System.out.println(parent[i] + " - " + i + "\t" + graph[i][parent[i]]);
                totalWeight += graph[i][parent[i]];
            }
        }

        System.out.println("Tổng trọng số MST: " + totalWeight);
    }
}
