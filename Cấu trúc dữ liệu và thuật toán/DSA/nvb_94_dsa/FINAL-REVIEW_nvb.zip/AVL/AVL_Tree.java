import java.util.*;

public class AVL_Tree {

    // A utility function to get the height 
    // of the tree
    public int height(Node N) {
        return (N == null) ? 0 : N.height;
    }

    // A utility function to right rotate 
    // subtree rooted with y
    public Node rightRotate(Node y) {
        Node lNode = y.left;
        Node lrNode = lNode.right;
        
        y.left = lrNode;
        lNode.right = y;
        
        y.height = Math.max(height(y.right), height(y.left)) + 1;
        lNode.height = Math.max(height(lNode.right), height(lNode.left)) + 1;
        
        return lNode;
    }

    // A utility function to left rotate 
    // subtree rooted with x
    public Node leftRotate(Node x) {
        Node rNode = x.right;
        Node rlNode = rNode.left;
        
        x.right = rlNode;
        rNode.left = x;
        
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        rNode.height = Math.max(height(rNode.left), height(rNode.right)) + 1;
        
        return rNode;
    }

    // Get Balance factor of node N
    public int getBalance(Node N) {
        return height(N.left) - height(N.right);
    }

    public Node insert(Node node, int key) {
        if (node == null) {
            return new Node(key);
        }
        
        if (key < node.key) {
            node.left = insert(node.left, key);
        } else if (key > node.key) {
            node.right = insert(node.right, key);
        } else {
            return node;
        }
        node.height = Math.max(height(node.left), height(node.right)) + 1;
        int balance = getBalance(node);
        
        if (balance > 1) {
            if (key < node.left.key) {
                return rightRotate(node);
            }
            if (key > node.left.key) {
                node.left = leftRotate(node.left);
                return rightRotate(node);
            }
        }
        
        if (balance < -1) {
            if (key < node.right.key) {
                return leftRotate(node);
            }
            
            if (key > node.right.key) {
                node.right = rightRotate(node.right);
                return leftRotate(node);
            }
        }
        
        return node;
    }



    // Recursive function to delete a node with 
    // given key from subtree with given root. 
    // It returns root of the modified subtree.
    public Node deleteNode(Node root, int key) {
        if (root == null) {
            return null;
        }
        
        if (root.key > key) {
            root.left = deleteNode(root.left, key);
        } else if (root.key < key) {
            root.right = deleteNode(root.right, key);
        } else if (root.key == key) {
            if ((root.left == null) || (root.right == null)) {
                Node temp = null;
                if (temp == root.left)
                    temp = root.right;
                else
                    temp = root.left;
                    
                if (temp == null) { 
                    temp = root;
                    root = null;
                } else
                    root = temp;
            } else {
                Node temp = minValueNode(root.right);
                root.key = temp.key;
                root.right = deleteNode(root.right, temp.key);
            }
        }
        if (root == null)
            return root;

        root.height = Math.max(height(root.left), height(root.right)) + 1;

        int balance = getBalance(root);

        if (balance > 1 && getBalance(root.left) >= 0)
            return rightRotate(root);

        if (balance > 1 && getBalance(root.left) < 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }

        if (balance < -1 && getBalance(root.right) <= 0)
            return leftRotate(root);

        if (balance < -1 && getBalance(root.right) > 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }
    
    private Node minValueNode(Node node) {
        Node current = node;
        while (current.left != null)
            current = current.left;
        return current;
    }

    // A utility function to print preorder 
    // traversal of the tree.
    public void preOrder(Node root) {
        if (root != null) {
            System.out.print(root.key + " ");
            preOrder(root.left);
            preOrder(root.right);
        }
    }


}