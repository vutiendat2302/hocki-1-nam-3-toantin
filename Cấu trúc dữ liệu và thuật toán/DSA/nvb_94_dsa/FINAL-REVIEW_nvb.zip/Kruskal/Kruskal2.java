import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Kruskal2 {
    int V;
    List<Edge> edges;

    Kruskal2(int vertices, List<List<Graph.Pair>> adjList) { // khởi tạo class, chuyển adjList sang danh sách cạnh
        V = vertices;
        Graph graph = new Graph(vertices);
        graph.adjList = adjList;
        edges = graph.getAllEdges();
    }


    public void kruskalMST() {
        if (edges == null || edges.size() == 0) {
            System.out.println("No edges found");
            return;
        }

        int[] parents = new int[V];
        Arrays.fill(parents, -1);

        int addedEdges = 0;
        int totalWeight = 0;

        Collections.sort(edges);

        for (int i = 0; i < edges.size() && addedEdges < V - 1; i++) {
            Edge currentEdge = edges.get(i);
            int src = currentEdge.src;
            int dest = currentEdge.dest;
            int srcRoot = getRoot(parents, src);
            int destRoot = getRoot(parents, dest);

            if (srcRoot != destRoot) {
                System.out.println(src + " -> " + dest + "(" + currentEdge.weight + ")");
                addedEdges++;
                totalWeight += currentEdge.weight;
                parents[srcRoot] = destRoot;
            }
        }
    }

    private int getRoot(int[] parent, int u) {
        if (parent[u] == -1) {
            return u;
        }

        parent[u] = getRoot(parent, parent[u]);
        return parent[u];
    }
}
