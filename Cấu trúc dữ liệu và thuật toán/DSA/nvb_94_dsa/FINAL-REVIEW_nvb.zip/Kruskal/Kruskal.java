import java.util.*;

class Kruskal {
    int V;
    List<Edge> edges;

    Kruskal(int vertices, List<List<Graph.Pair>> adjList) { // khởi tạo class, chuyển adjList sang danh sách cạnh
        V = vertices;
        Graph graph = new Graph(vertices);
        graph.adjList = adjList;
        edges = graph.getAllEdges();
    }


    public void kruskalMST() {
        // Kiểm tra nếu không có cạnh nào
        if (edges.isEmpty()) {
            System.out.println("Đồ thị không có cạnh nào.");
            return;
        }

        Collections.sort(edges);
        int[] parent = new int[V];
        for (int i = 0; i < V; i++) {
            parent[i] = -1;
        }

        System.out.println("Các cạnh trong cây bao trùm nhỏ nhất là: ");

        int edgesAdded = 0;
        int totalWeight = 0;

        // Sửa lỗi: lặp qua số lượng cạnh thực tế, không phải số đỉnh
        for (int i = 0; i < edges.size() && edgesAdded < V - 1; i++) {
            Edge currentEdge = edges.get(i);
            int src = currentEdge.src;
            int dest = currentEdge.dest;
            int srcRoot = getRoot(parent, src);
            int destRoot = getRoot(parent, dest);

            if (srcRoot != destRoot) {
                System.out.println(src + " -- " + dest + " (" + currentEdge.weight + ")");
                parent[srcRoot] = destRoot;
                edgesAdded++;
                totalWeight += currentEdge.weight;
            }
        }

        // In tổng trọng số thực tế
        if (edgesAdded > 0) {
            System.out.println("Tổng trọng số MST: " + totalWeight);
        }
    }

    private int getRoot(int[] parent, int u) {
        if (parent[u] == -1) {
            return u;
        }

        parent[u] = getRoot(parent, parent[u]);
        return parent[u];
    }
}
