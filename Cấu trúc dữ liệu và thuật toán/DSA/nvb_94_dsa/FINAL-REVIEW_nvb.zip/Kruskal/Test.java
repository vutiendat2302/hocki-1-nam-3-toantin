import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        System.out.println("=== KIỂM TRA THUẬT TOÁN KRUSKAL MST ===\n");

        // Test case 1: Đồ thị đơn giản
        testCase1();

        // Test case 2: Đồ thị phức tạp hơn
        testCase2();

        // Test case 3: Đồ thị với một đỉnh
        testCase3();

        // Test case 4: Đồ thị không liên thông
        testCase4();
    }

    /**
     * Test case 1: Đồ thị đơn giản 4 đỉnh
     */
    public static void testCase1() {
        System.out.println("--- TEST CASE 1: Đồ thị 4 đỉnh ---");

        // Tạo đồ thị 4 đỉnh
        Graph graph = new Graph(4);
        graph.addEdge(0, 1, 10);
        graph.addEdge(0, 2, 6);
        graph.addEdge(0, 3, 5);
        graph.addEdge(1, 3, 15);
        graph.addEdge(2, 3, 4);

        System.out.println("Đồ thị gốc:");
        printGraph(graph);

        // Chạy thuật toán Kruskal
        Kruskal2 kruskal = new Kruskal2(4, graph.adjList);
        kruskal.kruskalMST();

        System.out.println("Tổng trọng số MST mong đợi: 19\n");
    }

    /**
     * Test case 2: Đồ thị phức tạp hơn với 6 đỉnh
     */
    public static void testCase2() {
        System.out.println("--- TEST CASE 2: Đồ thị 6 đỉnh ---");

        Graph graph = new Graph(6);
        graph.addEdge(0, 1, 4);
        graph.addEdge(0, 2, 2);
        graph.addEdge(1, 2, 1);
        graph.addEdge(1, 3, 5);
        graph.addEdge(2, 3, 8);
        graph.addEdge(2, 4, 10);
        graph.addEdge(3, 4, 2);
        graph.addEdge(3, 5, 6);
        graph.addEdge(4, 5, 3);

        System.out.println("Đồ thị gốc:");
        printGraph(graph);

        Kruskal2 kruskal = new Kruskal2(6, graph.adjList);
        kruskal.kruskalMST();

        System.out.println("Tổng trọng số MST mong đợi: 16\n");
    }

    /**
     * Test case 3: Đồ thị với một đỉnh
     */
    public static void testCase3() {
        System.out.println("--- TEST CASE 3: Đồ thị 1 đỉnh ---");

        Graph graph = new Graph(1);
        // Không có cạnh nào

        System.out.println("Đồ thị gốc: Chỉ có 1 đỉnh, không có cạnh nào");

        Kruskal2 kruskal = new Kruskal2(1, graph.adjList);
        kruskal.kruskalMST();

        System.out.println("MST: Không có cạnh nào\n");
    }

    /**
     * Test case 4: Đồ thị không liên thông
     */
    public static void testCase4() {
        System.out.println("--- TEST CASE 4: Đồ thị không liên thông ---");

        Graph graph = new Graph(5);
        // Thành phần liên thông 1: đỉnh 0, 1, 2
        graph.addEdge(0, 1, 1);
        graph.addEdge(1, 2, 2);

        // Thành phần liên thông 2: đỉnh 3, 4
        graph.addEdge(3, 4, 3);

        System.out.println("Đồ thị gốc (không liên thông):");
        printGraph(graph);

        Kruskal2 kruskal = new Kruskal2(5, graph.adjList);
        kruskal.kruskalMST();

        System.out.println("MST sẽ tạo thành rừng (forest) với 2 cây con\n");
    }

    /**
     * Hàm phụ trợ: In đồ thị dạng danh sách kề
     */
    public static void printGraph(Graph graph) {
        for (int i = 0; i < graph.V; i++) {
            System.out.print("Đỉnh " + i + ": ");
            for (Graph.Pair pair : graph.adjList.get(i)) {
                System.out.print("(" + pair.vertex + ", " + pair.weight + ") ");
            }
            System.out.println();
        }
        System.out.println();
    }

    /**
     * Hàm phụ trợ: Tính tổng trọng số của tất cả cạnh trong MST
     * (Để kiểm tra kết quả)
     */
    public static int calculateMSTWeight(List<List<Graph.Pair>> adjList) {
        Graph graph = new Graph(adjList.size());
        graph.adjList = adjList;

        List<Edge> allEdges = graph.getAllEdges();
        Collections.sort(allEdges);

        int[] parent = new int[adjList.size()];
        Arrays.fill(parent, -1);

        int totalWeight = 0;
        int edgesAdded = 0;

        for (Edge edge : allEdges) {
            int srcRoot = findRoot(parent, edge.src);
            int destRoot = findRoot(parent, edge.dest);

            if (srcRoot != destRoot) {
                totalWeight += edge.weight;
                parent[srcRoot] = destRoot;
                edgesAdded++;

                if (edgesAdded == adjList.size() - 1) break;
            }
        }

        return totalWeight;
    }

    private static int findRoot(int[] parent, int vertex) {
        if (parent[vertex] == -1) {
            return vertex;
        }
        parent[vertex] = findRoot(parent, parent[vertex]);
        return parent[vertex];
    }
}
