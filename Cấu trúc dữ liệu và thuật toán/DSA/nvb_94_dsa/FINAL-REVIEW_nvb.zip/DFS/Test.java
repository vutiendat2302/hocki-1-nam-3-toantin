import java.util.List;

public class Test {
    public static void main(String[] args) {
        DFS dfsTest = new DFS();
        List<List<Integer>> adjList = List.of(
                List.of(1, 2),    // Đỉnh 0 kề 1, 2
                List.of(0, 3, 4),  // Đỉnh 1 kề 0, 3, 4
                List.of(0, 4),     // Đỉnh 2 kề 0, 4
                List.of(1),        // Đỉnh 3 kề 1
                List.of(1, 2)      // Đỉnh 4 kề 1, 2
        );
        dfsTest.dfs(adjList, 0);
    }
}
