import java.util.*;

class DFS {

    public void dfs(List<List<Integer>> adjList, int start) {
        Stack<Integer> stack = new Stack<>();
        stack.push(start);
        boolean[] visited = new boolean[adjList.size()];

        while (!stack.isEmpty()) {
            int current = stack.pop();

            if (!visited[current]) {
                System.out.println(current + " -> ");
                visited[current] = true;
            }

            for (int i = adjList.get(current).size() - 1; i >= 0; i--) {
                int neighbor = adjList.get(current).get(i);
                if (!visited[neighbor]) {
                    stack.push(neighbor);
                }
            }
        }
    }
}