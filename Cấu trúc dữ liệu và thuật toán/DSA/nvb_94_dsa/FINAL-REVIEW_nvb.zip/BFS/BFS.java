import java.io.*;
import java.util.*;
@SuppressWarnings({"unchecked", "deprecation"})
public class BFS
{
	public static List<List<Integer>> readGraphFromFile(String fileName) {
	    List<List<Integer>> adj = new ArrayList<>();
		try {
			File file = new File(fileName);
			Scanner getData = new Scanner(file);
			int n = Integer.parseInt(getData.nextLine());
			for (int i = 0; i < n; i++) {
				List<Integer> list = new ArrayList<>();
				String[] data = getData.nextLine().split(" ");
				for (int j = 1; j < data.length; j++) {
					list.add(Integer.parseInt(data[j]));
				}
				adj.add(list);
			}
			getData.close();
		} catch (FileNotFoundException e) {
			System.out.println("File " + fileName + " not found!");
			e.printStackTrace();
		}
		return adj;
    }

	public void bfs(List<List<Integer>> adjList, int start) {
		boolean[] visited = new boolean[adjList.size()];

		Queue<Integer> queue = new LinkedList<>();

		queue.add(start);
		visited[start] = true;

		while(!queue.isEmpty()) {
			int current = queue.poll();
			System.out.println(current + " ");

			for (int neighbor : adjList.get(current)) {
				if (!visited[neighbor]) {
					queue.add(neighbor);
					visited[neighbor] = true;
				}
			}
		}
    }
}
