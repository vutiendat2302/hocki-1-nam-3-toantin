import java.util.List;

public class Test {
    public static void main(String[] args) {
        BFS test = new BFS();
        List<List<Integer>> adjacentList = BFS.readGraphFromFile("adjList.txt");

        test.bfs(adjacentList, 0);
    }
}
