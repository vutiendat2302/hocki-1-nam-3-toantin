import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
@SuppressWarnings({"unchecked", "deprecation"})
public class AdjMatrix {
	
	private int[][] matrix;// ma trận kề
	private String[] v;// danh sách các đỉnh
	private int n;// số đỉnh
	
	public void loadGraphFromFile(String fileName)
	{
		try {
			File file = new File(fileName);
			Scanner getData = new Scanner(file);

			n = Integer.parseInt(getData.nextLine());
			v = new String[n];
			matrix = new int[n][n];

			for (int i = 0; i < n; i++) {
				v[i] = getData.nextLine().trim();
			}
			for (int i = 0; i < n; i++) {
				String data = getData.nextLine().trim();
				matrix[i] = parseDataToArray(data);
			}

			getData.close();
		} catch (FileNotFoundException e) {
			System.out.println("File " + fileName + " not found!");
			e.printStackTrace();
		}
	}

	private int[] parseDataToArray(String line) {
		String[] tokens = line.split(" ");
		int[] arr = new int[tokens.length];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = Integer.parseInt(tokens[i]);
		}
		return arr;
	}
	
	public List<String> getAdjList()
	{
		List<String> result = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			StringBuilder near = new StringBuilder();
			near.append(v[i]);
			for (int j = 0; j < n; j++) {
				if (matrix[i][j] == 1) {
					near.append("->").append(v[j]);
				}
			}
			result.add(near.toString());
		}
		return result;
	}
	

}

/*
Hoàn thành các phương thức trong file AdjMatrix theo mô tả sau:

		- phương thức public void loadGraphFromFile(String fileName) thực hiện nhập các thông tin của đồ thị từ file.

		--- Cấu trúc file như sau:

Dòng đầu tiên là số đỉnh của đồ thị n

n dòng tiếp theo là tên các đỉnh

Cuối cùng là ma trận kề của đồ thị (nxn số nguyên)

Ví dụ

----------------------------

		5

H

		K

B

		D

T

0 1 0 0 1

		1 0 1 1 1

		0 1 0 0 1

		0 1 0 0 1

		1 1 1 1 0

		-----------------

		- public List<String> getAdjList() trả lại danh sách kề của đồ thị, mỗi String là danh sách kề của 1 đỉnh. Ví dụ với đồ thị trên thì danh sách kề trả về là

H->K->T

K->H->B->D->T

B->K->T

D->K->T

T->H->K->B->D

List gồm 5 phần tử, mỗi phần tử là 1 String như trên.*/
