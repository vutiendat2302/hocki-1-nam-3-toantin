import java.util.List;

public class Test {
    private static AdjMatrix matrix;
    public static void main(String[] args) {
        matrix = new AdjMatrix();
        matrix.loadGraphFromFile("nearList.txt");

        List<String> list = matrix.getAdjList();
        for (String s : list) {
            System.out.println(s);
        }
    }
}
