class MyQueue
{
    QueueNode front, rear;
    
    //Function to push an element into the queue.
	void enqueue(int a)
	{
    	QueueNode next = new QueueNode(a);
	    if (rear != null) {
    	    rear.next = next;
	    } else {
	        front = rear = next;
	    }

	}
	
    //Function to pop front element from the queue.
	int dequeue()
	{
        // Your code here
        if (front != null) {
            int popValue = front.data;
            front = front.next;
            return popValue;
        }
        
        if (front == null) {
            rear = null;
        }
        
        return -1;
	}
}
