import java.util.List;
import java.util.Queue;
import java.util.ArrayList;
import java.util.LinkedList;

class RightSideView {


    public List<Integer> rightSideView(TreeNode root) {
        Queue<TreeNode> queue = new LinkedList<>();
        List<Integer> result = new ArrayList<>();
        
        if (root == null) {
            return result;
        }
        
        queue.offer(root);
        
        while (!queue.isEmpty()) {
            int level = queue.size();
            
            for (int i = 0; i < level; i++) {
                TreeNode current = queue.poll();
                
                if (i == level - 1) {
                    result.add(current.val);
                }
                
                if (current.left != null) {
                    queue.offer(current.left);
                }
                
                if (current.right != null) {
                    queue.offer(current.right);
                }
            }
        }
        
        return result;
        
    }
}