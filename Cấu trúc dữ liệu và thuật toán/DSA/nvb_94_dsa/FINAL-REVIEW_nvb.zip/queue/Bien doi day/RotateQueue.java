import java.util.*;

class RotateQueue
{
    public Queue rotate(int a[], int n, int k)
    {
        Queue<Integer> queue = new LinkedList<>();
        
        for (int i = 0; i < n; i++) {
            queue.offer(a[i]);
        }
        
        for (int i = 0; i < k; i++) {
            int temp = queue.poll();
            queue.offer(temp);
        }
        
        return queue;
    }
}