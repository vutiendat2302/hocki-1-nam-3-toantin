import java.util.Stack;
public class Expression{
    
    public boolean isValidExpr(String expr)
    {
        Stack<Character> valid = new Stack<>();
        
        for (int i = 0; i < expr.length(); i++) {
            char pattern = expr.charAt(i);
            if (pattern  == '(' || pattern == '{' || pattern == '[') {
                valid.push(pattern);
            }
            else if (pattern == ')' || pattern == '}' || pattern == ']') {
                if (valid.isEmpty()) {
                    return false;
                }

                char top = valid.peek();
                if ((pattern == ')' && top == '(')
                || (pattern == '}' && top == '{')
                || (pattern == ']' && top == '[')) {
                    valid.pop();
                } else {
                    return false;
                }
            }
        }
        return valid.isEmpty();
    }
    
    public static void main(String[] args)
    {
        
        Expression expr = new Expression();
        String f = "a+b-c(3+a)";
        System.out.println(expr.isValidExpr(f));
        
    }
    
    
}