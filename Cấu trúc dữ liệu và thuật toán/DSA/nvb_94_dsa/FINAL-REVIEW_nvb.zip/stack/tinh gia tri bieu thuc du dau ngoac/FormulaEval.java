
public class FormulaEval {

	public double eval(String formula)
	{
	    LinkedListStack<Double> value = new LinkedListStack<>();
	    LinkedListStack<String> operator = new LinkedListStack<>();
	    
		String [] split = formula.split("\\s+");
		for (String element : split) {
		    if (element.matches("-?\\d+(\\.\\d+)?")) {
		        value.push(Double.parseDouble(element));
		    }
		    if (element.equals("(")) {
		        operator.push(element);
		    }
            else if (element.equals("+") || element.equals("-") || element.equals("*") || element.equals("/")) {
                while (!operator.isEmpty() && !operator.peek().equals("(") && getPriority(operator.peek()) >= getPriority(element)) {
                    double val1 = value.pop();
                    double val2 = value.pop();
                    value.push(cal(operator.pop(), val2, val1));
                }
                operator.push(element);
            }
            else if (element.equals(")")) {
                while (!operator.isEmpty() && !operator.peek().equals("(")) {
                    double val1 = value.pop();
                    double val2 = value.pop();
                    value.push(cal(operator.pop(),val2 , val1));
                }
                if (!operator.isEmpty()) {
                    operator.pop();
                } else {
                    return -1;
                }
            }
		}
	
		return value.peek();
	}
	
	private int getPriority(String opt) {
	    if (opt.equals("+") || opt.equals("-")) {
	        return 4;
	    }
	    
	    if (opt.equals("*") || opt.equals("/")) {
	        return 5;
	    }
	    
	    return -1;
	}
	
	private double cal(String opt, double val1, double val2) {
	    switch (opt) {
	        case "+":
	            return val1 + val2;
	        case "-":
	            return val1 - val2;
	        case "*":
	            return val1 * val2;
	        case "/":
	            return val2 / val1;
	        default:
	            throw new ArithmeticException();
	    }
	}

}
