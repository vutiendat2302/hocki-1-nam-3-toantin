import java.util.Iterator;

public class LinkedListStack<T> implements StackInterface<T> {

	class Node {
		T element;
		Node next;
		
		Node(T element) {
		    this.element = element;
		    this.next = null;
		}
	}

	Node stack = null;

	@Override
	public void push(T element) {
		// TODO Auto-generated method stub
	    Node newHead = new Node(element);
	    newHead.next = stack;
	    stack = newHead;
	}

	@Override
	public T pop() {
		// TODO Auto-generated method stub
	
		T top = stack.element;
		stack = stack.next;
		return top;
	}
	
	public T peek() {
	    return stack.element;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return  stack == null;
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new StackIterator();
	}

	class StackIterator implements Iterator<T> {

		private Node currentNode = stack;

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return currentNode != null;
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			T data = currentNode.element;
			currentNode = currentNode.next;
			return data;
		}
	}

}
